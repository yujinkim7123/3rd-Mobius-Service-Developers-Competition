$(pkill mjpg_streamer)echo "streaming stopped!"
